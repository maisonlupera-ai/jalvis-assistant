# JALVIS – personal AI assistant + LUPÉRA dashboard
Installable Android app (PWA → APK). Files: index.html, manifest.json, sw.js, icon-192.png, icon-512.png, .nojekyll

## Voice commands (Hindi / Hinglish / English)
- order Priya kurta 2 1500      - sale saree 2400
- kharcha 300 packaging         - stock kurta 20 (adds), "stock" (shows low)
- yaad dilao 30 minute me dispatch / kal 5 baje call
- meeting Vendor call kal 4 baje (also adds to Google Calendar)
- mail  |  calendar  |  aaj ka report
Anything else -> Claude (if you add an API key in Settings).

## Build the APK from your phone only
1. Unzip this file in the Files app.
2. In Chrome open github.com, sign up, create a PUBLIC repo named  YOURNAME.github.io
   (this exact form puts the app at the domain root, which Android needs to hide the browser bar).
3. Add file > Upload files: select ALL files from the unzipped folder (incl. .nojekyll) > Commit.
4. Repo Settings > Pages > Deploy from branch: main / root. Wait 1-2 min.
5. Open https://YOURNAME.github.io in Chrome. Test it. (Menu > Install app already works as an app.)
6. Open pwabuilder.com in Chrome > paste the URL > Start > Package for stores > Android.
   Package ID: com.yourname.jalvis. Signing key: "New". Generate, download the zip.
7. Unzip it. Install the .apk (Files app > tap > allow "install unknown apps").
8. For a full-screen app with no URL bar: upload the assetlinks.json from that zip into your repo at
   .well-known/assetlinks.json (GitHub: Add file > Create new file > name it .well-known/assetlinks.json > paste).
   Keep the signing key from the zip safe; you need it for updates.

## Google Gmail + Calendar
console.cloud.google.com > new project > enable Gmail API and Google Calendar API >
OAuth consent screen (External, Testing, add your own Gmail as test user) >
Credentials > OAuth client ID > Web application > Authorized JavaScript origins:
https://YOURNAME.github.io > copy the Client ID into JALVIS Settings.
Scopes are read-only Gmail + calendar events. Tokens stay in memory only.

## Security
PIN -> PBKDF2 (250k) -> AES-256-GCM encrypted local data, 5-try limit, 2-min auto-lock, strict CSP,
no server, no analytics. Backup export excludes keys. Claude API key is stored encrypted on-device.
Limitations: if the phone is rooted/compromised or a weak PIN is used, data is at risk.
Reminders ring while the app is open; for reminders when closed, use "meeting ..." (Google Calendar notifies).
Deep voice: set the pitch slider low and install a male Hindi/English voice in Android Settings > Text-to-speech.
